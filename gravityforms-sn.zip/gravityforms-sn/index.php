<?php
/*
Plugin Name: درگاه پرداخت آنلاین گرویتی فرم
Plugin URI: http://gravityforms.ir/
Description: افزونه درگاه پرداخت آنلاین برای فرم ساز فوق پیشرفته Gravity Forms
Version: 2.2.2
Author: حنان ابراهیمی ستوده
Author URI: http://hannanstd.ir/
*/
if (!defined('ABSPATH')) exit;
require_once('sn.php');